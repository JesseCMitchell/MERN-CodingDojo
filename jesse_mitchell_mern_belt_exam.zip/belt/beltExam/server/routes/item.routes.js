/** @format */

const ItemController = require('../controllers/item.controller');

module.exports = app => {
	app.get('/api/pirates', ItemController.findAllItems);
	app.post('/api/pirates', ItemController.createItem);
	app.get('/api/pirates/:_id', ItemController.findOneItem);
	app.put('/api/pirates/:_id', ItemController.updateOneItem);
	app.delete('/api/pirates/:_id', ItemController.deleteItem);
};
