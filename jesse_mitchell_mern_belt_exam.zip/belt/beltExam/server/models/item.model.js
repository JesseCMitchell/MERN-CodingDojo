/** @format */

const mongoose = require('mongoose');

const BeltExamSchema = new mongoose.Schema(
	{
		title: {
			type: String,
			required: [true, 'Name is required'],
			minlength: [3, 'Name must be at least 3 characters'],
		},
		imgUrl: {
			type: String,
			required: [true, 'Must have photo ID!'],
			minlength: [10, 'Image Url must be at least 10 characters'],
		},
		treasure: {
			type: Number,
			required: [true, 'Treasure is required'],
			min: [0, 'Treasure must be greater than zero'],
		},
		catchphrase: {
			type: String,
			required: [true, 'Catchphrase is required'],
			minlength: [3, 'Catchphrase must be at least 3 characters'],
		},
		dropdown: {
			type: String,
			// required: [true, 'Crew position required'],
		},
		pegBox: {
			type: Boolean,
			required: [true, 'Required'],
		},
		eyeBox: {
			type: Boolean,
			required: [true, 'Required'],
		},
		hookBox: {
			type: Boolean,
			required: [true, 'Required'],
		},
	},
	{ timestamps: true },
);

// module.exports.Product = mongoose.model("Product", BeltExamSchema);
const Item = mongoose.model('Item', BeltExamSchema);
module.exports = Item;
