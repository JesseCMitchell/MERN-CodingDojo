/** @format */

import React, { useState } from 'react';
import axios from 'axios';
import Form from './Form';
import { useNavigate, Link } from 'react-router-dom';

const ItemForm = props => {
	let [formInfo, setFormInfo] = useState({});
	let [formErrors, setFormErrors] = useState({});

	const changeHandler = e => {
		if (e.target.type === 'dropdown') {
			setFormInfo({
				...formInfo,
				[e.target.name]: e.target.value,
			});
		}
		if (e.target.type === 'checkbox') {
			setFormInfo({
				...formInfo,
				[e.target.name]: e.target.checked,
			});
		} else {
			setFormInfo({
				...formInfo,
				[e.target.name]: e.target.value,
			});
		}
	};
	const navigate = useNavigate();
	// if there are any errors, then save the errors to a state variable
	// when submitting an incomplete form -> response looks like this: response.data.errors
	// when submitting a complete form -> response looks like this: response.data.results
	const handleSubmit = e => {
		e.preventDefault();
		axios
			.post('http://localhost:8000/api/pirates', formInfo)
			.then(response => {
				console.log('Submission form errors');
				if (response.data.errors) {
					setFormErrors(response.data.errors);
				} else {
					console.log('form was submitted');
					setFormErrors({});
					props.setFormSubmitted(props.formSubmitted);
					navigate('/');
				}
			})
			.catch(err => console.log(err));
	};

	// returning the create form from our Form.js
	return (
		<div>
			<h3>Add Pirate</h3>
			<Link to={`/`} className='btn btn-outline-primary shadow m-3'>
				Crew Board
			</Link>
			<Form
				changeHandler={changeHandler}
				handleSubmit={handleSubmit}
				formInfo={formInfo}
				formErrors={formErrors}
				buttonValue={'Add Pirate'}></Form>
		</div>
	);
};

export default ItemForm;
