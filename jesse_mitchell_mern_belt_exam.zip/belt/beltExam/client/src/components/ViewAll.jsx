/** @format */
import '../App.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Paper from '@mui/material/Paper';

const styles = {
	paper: {
		width: 'auto',
		padding: '1rem',
		background_color: 'orange',
	},
	input: {
		marginBottom: '1rem',
	},
};

const AllItems = props => {
	let [items, setItems] = useState([]);
	let [itemDeleted, setItemDeleted] = useState(false);

	useEffect(() => {
		axios
			.get('http://localhost:8000/api/pirates')
			.then(response => {
				console.log('response: ', response);
				setItems(response.data.results);
			})
			.catch(err => console.log(err));
	}, [itemDeleted, props.formSubmitted]);

	const deleteItem = _id => {
		axios
			.delete(`http://localhost:8000/api/pirates/${_id}`)
			.then(response => {
				setItemDeleted(!itemDeleted);
			})
			.catch(err => console.log(err));
	};

	return (
		<Paper elevation={3} style={styles.paper}>
			<div>
				<Link to={`/items/create`} className='btn btn-primary m-3 shadow'>
					Add a Pirate
				</Link>
				{items.map(item => {
					return (
						<div key={items._id} className='card mb-3 p-3'>
							<table className='table'>
								<tbody>
									<tr>
										<td>
											<div className='d-flex align-items-center'>
												<img
													className='mx-auto'
													src={item.imgUrl}
													alt={item.title}
													height='200px'
													width='150px'
												/>
											</div>
										</td>
										<td>
											<h2>
												<Link to={`/items/${item._id}`}>{item.title}</Link>
											</h2>
											<Link
												to={`/items/edit/${item._id}`}
												className='btn btn-warning m-3 shadow'>
												Edit {item.title}
											</Link>
											<button
												className='btn btn-danger m-3 shadow'
												onClick={() => deleteItem(item._id)}>
												Walk the Plank
											</button>
										</td>
									</tr>
									<td></td>
								</tbody>
							</table>
						</div>
					);
				})}
			</div>
		</Paper>
	);
};

export default AllItems;
