/** @format */

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams, Link } from 'react-router-dom';
import moment from 'moment';

const OneItem = () => {
	const { _id } = useParams();
	const [details, setDetails] = useState({});
	const [notFound, setNotFound] = useState(false);
	const navigate = useNavigate();

	useEffect(() => {
		axios
			.get(`http://localhost:8000/api/pirates/${_id}`)
			.then(response => {
				console.log('response: ', response);
				if (response.data.results) {
					setDetails(response.data.results);
				} else {
					setNotFound(true);
				}
			})
			.catch(err => console.log(err));
	}, []);

	const deleteItem = () => {
		axios
			.delete(`http://localhost:8000/api/pirates/${_id}`)
			.then(response => {
				console.log('response', response);
				navigate('/');
			})
			.catch(err => console.log(err));
	};

	return (
		<div>
			{notFound === true ? (
				<img
					src='https://c.tenor.com/C3_eITLs5AQAAAAC/johnny-depp-confused.gif'
					alt=''
					height='500px'
					width='900'
				/>
			) : (
				<>
					<h2>{details.title}</h2>
					<div className='card mb-2 p-3 shadow'>
						<div className='row g-0'>
							<div className='col-md-4'>
								<img
									className='mx-auto'
									src={details.imgUrl}
									alt={details.title}
									height='300px'
									width='300px'
								/>
								<h1>"{details.catchphrase}"</h1>
							</div>
							<div className='col-md-8'>
								<div className='card-body'>
									<h3 className='card-title'>About</h3>
									<p className='card-text'>Treasures: {details.treasure}</p>
									<p className='card-text'>Position: {details.dropdown}</p>
									<p className='card-text'>
										Peg Leg: {details.pegBox ? 'Yes' : 'No'}
									</p>
									<p className='card-text'>
										Eye Patch: {details.eyeBox ? 'Yes' : 'No'}
									</p>
									<p className='card-text'>
										Hook Hand: {details.hoookBox ? 'Yes' : 'No'}
									</p>
								</div>
							</div>
						</div>
					</div>
					<div>
						<button className='btn btn-danger m-3' onClick={deleteItem}>
							Delete {details.title}
						</button>
						<Link to={`/items/edit/${details._id}`} className='btn btn-warning m-3'>
							Edit {details.title}
						</Link>
						<Link to={`/`} className='btn btn-primary m-3'>
							Back
						</Link>
					</div>
				</>
			)}
		</div>
	);
};

export default OneItem;
