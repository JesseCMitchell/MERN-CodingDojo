/** @format */

import React from 'react';
import Paper from '@mui/material/Paper';
import FormGroup from '@mui/material/FormGroup';
import TextField from '@mui/material/TextField';

const styles = {
	paper: {
		width: 'auto',
		padding: '1rem',
	},
	input: {
		marginBottom: '1rem',
	},
};

// Making a reusable form component
const Form = props => {
	const { handleSubmit, changeHandler, formInfo, formErrors } = props;

	return (
		<div>
			<Paper elevation={3} style={styles.paper}>
				<form onSubmit={handleSubmit}>
					<FormGroup variant='outlined' style={styles.input}>
						<TextField
							label='Pirate Name:'
							variant='outlined'
							color='primary'
							className='form-control'
							type='text'
							name='title'
							onChange={changeHandler}
							value={formInfo.title}
							required
							error={formErrors.title?.message}
							helperText={formErrors.title?.message}
						/>
					</FormGroup>
					<FormGroup variant='outlined' style={styles.input}>
						<TextField
							label='Image Url:'
							variant='outlined'
							color='primary'
							className='form-control'
							type='text'
							name='imgUrl'
							onChange={changeHandler}
							value={formInfo.imgUrl}
							required
							error={formErrors.imgUrl?.message}
							helperText={formErrors.imgUrl?.message}
						/>
					</FormGroup>
					<FormGroup variant='outlined' style={styles.input}>
						<TextField
							label='# of Treasure Chests:'
							variant='outlined'
							color='primary'
							className='form-control'
							type='number'
							name='treasure'
							onChange={changeHandler}
							value={formInfo.treasure}
							required
							error={formErrors.treasure?.message}
							helperText={formErrors.treasure?.message}
						/>
					</FormGroup>
					<FormGroup variant='outlined' style={styles.input}>
						<TextField
							label='Pirate Catch Phrase'
							variant='outlined'
							color='primary'
							className='form-control'
							type='text'
							name='catchphrase'
							onChange={changeHandler}
							value={formInfo.catchphrase}
							required
							error={formErrors.catchphrase?.message}
							helperText={formErrors.catchphrase?.message}
						/>
					</FormGroup>
					<br />
					<select
						label='Crew Position'
						className='ms-3 shadow'
						onChange={changeHandler}
						type='dropdown'
						name='dropdown'
						value={formInfo.dropdown}>
						<option value=''></option>
						<option value='Captian'>Captian</option>
						<option value='First Mate'>First Mate</option>
						<option value='Quarter Master'>Quarter Master</option>
						<option value='Boatswain'>Boatswain</option>
						<option value='Powder Monkey'>Powder Monkey</option>
					</select>
					<br />
					<div className='form-group'>
						<label htmlFor=''>Peg Leg: </label>
						<input
							className='form-check-input ms-2'
							id='pegBox'
							type='checkbox'
							name='pegBox'
							onChange={changeHandler}
							value={formInfo.pegBox}
							checked={formInfo.pegBox}
						/>
					</div>
					<div className='form-group'>
						<label htmlFor=''>Eye Patch: </label>
						<input
							className='form-check-input ms-2'
							id='eyeBox'
							type='checkbox'
							name='eyeBox'
							onChange={changeHandler}
							value={formInfo.eyeBox}
							checked={formInfo.eyeBox}
						/>
					</div>
					<div className='form-group'>
						<label htmlFor=''>Hook Hand: </label>
						<input
							className='form-check-input ms-2'
							id='hookBox'
							type='checkbox'
							name='hookBox'
							onChange={changeHandler}
							value={formInfo.hookBox}
							checked={formInfo.hookBox}
						/>
					</div>
					<br />
					<input
						type='submit'
						value={props.buttonValue}
						className='btn btn-primary shadow'
						onChange={changeHandler}
					/>
				</form>
			</Paper>
		</div>
	);
};

export default Form;
